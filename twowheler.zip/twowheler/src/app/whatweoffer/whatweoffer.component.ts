import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whatweoffer',
  templateUrl: './whatweoffer.component.html',
  styleUrls: ['./whatweoffer.component.css']
})
export class WhatweofferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
