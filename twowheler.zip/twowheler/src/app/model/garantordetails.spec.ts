import { Garantordetails } from './garantordetails';

describe('Garantordetails', () => {
  it('should create an instance', () => {
    expect(new Garantordetails()).toBeTruthy();
  });
});
