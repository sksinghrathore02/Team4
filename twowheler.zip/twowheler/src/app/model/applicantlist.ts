export class Applicantlist {
    id:number;
    name:string;
    age:number;
    emailid:string;
    sanctionamount:number;
    status:string;
    action:string;



}
