export class Carinfo {
    carmodelno:number;
	carname:number;
	brandname:string;
carprice:number;

}
