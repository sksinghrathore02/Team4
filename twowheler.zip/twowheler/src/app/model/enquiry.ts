export class Enquiry {
     cid:number;
firstname:string;
lastname:string;
age:number;
email:string;
mobileno:string;
pancardno:string;
cibilscore:number;
status:string;
}
