import { Emidetails } from "./emidetails";

export class Currentloandetails {
currentloanid:number;
currentloanno:number;
emiamount:number;
loanamount:number;
rateofinterest:number;
tenure:number;
totalamtpaid:number;
processingfees:number;
totalinterest:number;
sanctiondate:string;
}
