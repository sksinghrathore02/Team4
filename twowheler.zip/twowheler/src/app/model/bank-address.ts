export class BankAddress {
addid:number;
areaname:string ;
cityname:string ;
district:string ;
state:string;
streetname:string;
pincode:string;
}
