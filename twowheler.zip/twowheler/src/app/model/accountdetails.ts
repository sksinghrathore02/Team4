export class Accountdetails {
    accountId:number;
	accounType:string;
    accountBalance:number;
	accountHolderName:string;
	accountStatus:string;
	accountNumber:number;
}
