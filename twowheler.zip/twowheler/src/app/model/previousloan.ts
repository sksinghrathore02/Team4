import { PreviousLoanbankDetails } from "./previous-loanbank-details";

export class Previousloan {
previousloanid:number;
previousloanamount:number;
previousloantenure:number;
previousloanpaidamount:number;
previousloanremainingAmount:number;
previousloandefaulterCount:string;
previousloanstatus:string;
previousloanremark:string;
//previousLoanbankDetails:PreviousLoanbankDetails[];

}
