export class Ledger {
    ledgerId:number;
    ledgerCreatedDate:string;
    totalLoanAmount:number;
    payableAmountwithInterest:number;
    tenure:number;
    monthlyEMI:number;
    amountPaidtillDate:number;
    remainingAmount:number;
    nextEmiDatestart:string;
    nextEmiDateEnd:string;
    defaulterCount:number;
    previousEmitStatus:string;
    currentMonthEmiStatus:string;
    loanEndDate:number;
    loanStatus:string;

}
