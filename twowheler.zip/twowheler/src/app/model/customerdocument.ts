export class Customerdocument {
    docId:number;
	cid:number;
	
 profilePhoto :[];
	signature:[];
	
	pancard:[];

	adharcardaddressproof:[];

	 incomeproof:[];

	
}
