import { Applicantlist } from './applicantlist';

describe('Applicantlist', () => {
  it('should create an instance', () => {
    expect(new Applicantlist()).toBeTruthy();
  });
});
