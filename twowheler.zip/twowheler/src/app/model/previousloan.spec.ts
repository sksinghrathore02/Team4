import { Previousloan } from './previousloan';

describe('Previousloan', () => {
  it('should create an instance', () => {
    expect(new Previousloan()).toBeTruthy();
  });
});
