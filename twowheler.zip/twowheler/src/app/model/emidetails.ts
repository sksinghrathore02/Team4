export class Emidetails {
    id:number;
    emailid:String;
emiAmountMonthly:String;
nextemiduedate:String;
previousemistatus:String;
}
