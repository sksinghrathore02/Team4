export class Profession {
    professionid:number;
professiontype:string;
professionsalary:number;
profsalarytype:string;
professionworkingperiod:string;
professiondesignation:string;
}
