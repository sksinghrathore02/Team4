import { Currentloandetails } from './currentloandetails';

describe('Currentloandetails', () => {
  it('should create an instance', () => {
    expect(new Currentloandetails()).toBeTruthy();
  });
});
