export class CustomerAddress {
customeraddressid:number;
areaname:string;
cityname:string;
district:string;
state:string;
streetname:string;
houseno:number;
pincode:number;
}
