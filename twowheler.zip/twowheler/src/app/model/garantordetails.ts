export class Garantordetails {
    gid:number;
	gdob:string;
    gname:string;
	gmobileno:number;
	gaddress:string;
	relationship:string;
	occupation:string;
	detailsofincome:number;
	pandetails:number;
	gender:string;
	areaname:string;
	cityname:string;
	district:string;
	state:string;
	streetname:string;
	pincode:number;
}
