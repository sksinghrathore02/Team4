import { Educationdetails } from './educationdetails';

describe('Educationdetails', () => {
  it('should create an instance', () => {
    expect(new Educationdetails()).toBeTruthy();
  });
});
