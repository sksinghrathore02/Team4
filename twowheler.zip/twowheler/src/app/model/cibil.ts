export class Cibil {
    cid:number;
cibilscore:number;
scoreabove:number;
scorebelow:number;
mark:number;
}
