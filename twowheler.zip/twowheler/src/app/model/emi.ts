export class Emi {
    id:number;
emailid:string;
emiAmountMonthly:string;
nextemiduedate:string;
previousemistatus:string;
}
