import { BankAddress } from "./bank-address";

export class PreviousLoanbankDetails {
    branchid:number;
    branchname:string;
    branchcode:string;
    contactnumber:string;
    IFSCcode:string;
    Micrcode:string;
    branchtype:string;
    Email:string;
    status:string;
    //bankaddress:BankAddress[] ;  
    bankaddress:string;
}
