import { Emi } from './emi';

describe('Emi', () => {
  it('should create an instance', () => {
    expect(new Emi()).toBeTruthy();
  });
});
