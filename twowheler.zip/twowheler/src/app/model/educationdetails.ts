export class Educationdetails {
    eduid:number;
educationtype:string;
}
