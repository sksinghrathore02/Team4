export class Email {
    id:number;
	name:String;
	sender:String;
	receiver:String;
	status:String;
	
	
}
