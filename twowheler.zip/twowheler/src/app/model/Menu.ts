export class Menu {
    public static menu: Array<any> = [
      {
        admin: [
          {path: "adminbash", title: "Dashbord", icon: "pe-7s-graph", class: "" },
          {path: "city", title: "Create Student", icon: "pe-7s-graph", class: "" }
      ],
      emp: [
        {path: "empdash", title: "dashbord", icon: "pe-7s-graph", class: "" },
        {path: "demo", title: "Demmmo", icon: "pe-7s-graph", class: "" }
  
    ],
  
    operation:[
      {path: "oedash", title: "DASHBORD", icon: "pe-7s-graph", class: "" },
      {path: "oeenq", title: "VIEW ENQUIERY", icon: "pe-7s-graph", class: "" },
      {path: "oecustomer", title: "VIEW CUSTOMER", icon: "pe-7s-graph", class: "" },
      {path: "cibil", title: "CIBILSCORE", icon: "pe-7s-graph", class: "" }
    ],
    relation:[{path: "abcdash", title: "DASHBOARD", icon: "pe-7s-graph", class: "" },
        {path: "oeenquiry", title: "ENQUERY", icon: "pe-7s-graph", class: "" },
        {path: "oecustomer", title: "REGISTER CUSTOMER", icon: "pe-7s-graph", class: "" },
        {path: "oedocument", title: "UPLOAD DOCUMENT", icon: "pe-7s-graph", class: "" },
        {path: "oeviewenq", title: "view Enquiry", icon: "pe-7s-graph", class: "" }

      ],
      cr:[{path: "credit", title: "ENQUERY", icon: "pe-7s-graph", class: "" },
      {path: "viewapp", title: "ViewApp", icon: "pe-7s-graph", class: "" }

      ],
      bm:[
      {path: "viewapp", title: "ViewApp", icon: "pe-7s-graph", class: "" },
      {path:'emi', title: "Emi", icon: "pe-7s-graph", class: "" },
      {path:'emidetails', title: "EmiDetails", icon: "pe-7s-graph", class: "" }

      ],
      ah:[{path: "abcdash", title: "DASHBOARD", icon: "pe-7s-graph", class: "" },
        {path: "sanction", title: "Sanction", icon: "pe-7s-graph", class: "" },
      {path: "viewapp", title: "ViewApp", icon: "pe-7s-graph", class: "" }

      ],

      ab:[{path: "abcdash", title: "DASHBOARD", icon: "pe-7s-graph", class: "" }],
      th:[{path: "abcdash", title: "DASHBOARD", icon: "pe-7s-graph", class: "" },
      {path: "viewapplication", title: "ViewApp", icon: "pe-7s-graph", class: "" },
      {path:'viewdefault', title: "Emi", icon: "pe-7s-graph", class: "" }]
      }
    ];
  }
  