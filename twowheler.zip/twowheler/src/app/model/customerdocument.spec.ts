import { Customerdocument } from './customerdocument';

describe('Customerdocument', () => {
  it('should create an instance', () => {
    expect(new Customerdocument()).toBeTruthy();
  });
});
