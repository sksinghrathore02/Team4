import { PreviousLoanbankDetails } from './previous-loanbank-details';

describe('PreviousLoanbankDetails', () => {
  it('should create an instance', () => {
    expect(new PreviousLoanbankDetails()).toBeTruthy();
  });
});
