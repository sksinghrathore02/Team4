export class Sanction {

sanctionId:number;
sanctionDate:string;
applicantName:String;
contactDetails:string;
productHomeEnquiry:string;
loanAmountSanctioned:number;
interestType:string;
rateOfInterest:number;
loanTenure:number;
monthlyEmiAmount:number;
modeOfPayment:string;
remarks:string;
termsCondition:string;
status:string;
}
