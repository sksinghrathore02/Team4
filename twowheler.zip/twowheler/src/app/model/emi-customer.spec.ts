import { EmiCustomer } from './emi-customer';

describe('EmiCustomer', () => {
  it('should create an instance', () => {
    expect(new EmiCustomer()).toBeTruthy();
  });
});
