import { Carinfo } from './carinfo';

describe('Carinfo', () => {
  it('should create an instance', () => {
    expect(new Carinfo()).toBeTruthy();
  });
});
