export class Mail {
    eid:number;
    toMail:string;
	fromMail:string;
	subject:string;
	body:string;
	attchment:[];
    
}
