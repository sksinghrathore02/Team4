import { Emidetails } from './emidetails';

describe('Emidetails', () => {
  it('should create an instance', () => {
    expect(new Emidetails()).toBeTruthy();
  });
});
