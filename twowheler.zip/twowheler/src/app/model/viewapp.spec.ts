import { Viewapp } from './viewapp';

describe('Viewapp', () => {
  it('should create an instance', () => {
    expect(new Viewapp()).toBeTruthy();
  });
});
