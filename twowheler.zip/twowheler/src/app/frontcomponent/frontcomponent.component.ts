import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frontcomponent',
  templateUrl: './frontcomponent.component.html',
  styleUrls: ['./frontcomponent.component.css']
})
export class FrontcomponentComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
