import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-app',
  templateUrl: './view-app.component.html',
  styleUrls: ['./view-app.component.css']
})
export class ViewAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
