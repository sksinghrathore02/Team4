import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-processtoapply',
  templateUrl: './processtoapply.component.html',
  styleUrls: ['./processtoapply.component.css']
})
export class ProcesstoapplyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
