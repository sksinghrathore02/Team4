export class Enquiry {
    
}
