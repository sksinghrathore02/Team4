package com.app.main.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.main.model.ApplicantList;




@Repository
public interface ApplicantRepository extends CrudRepository<ApplicantList, Integer>
{

}
