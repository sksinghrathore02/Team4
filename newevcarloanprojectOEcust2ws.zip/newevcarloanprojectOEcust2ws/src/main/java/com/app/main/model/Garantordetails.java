package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Garantordetails {
	@Id
	@GeneratedValue
	private int gid;
	private String gdob;
	private String gname;
	private long gmobileno;
	private String gaddress;
	private String relationship;
	private String occupation;
	private double detailsofincome;
	private String pandetails;
	private String gender;
	private String areaname;
	private String cityname;
	private String district;
	private String state;
	private String streetname;
	private long pincode;
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getGdob() {
		return gdob;
	}
	public void setGdob(String gdob) {
		this.gdob = gdob;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public long getGmobileno() {
		return gmobileno;
	}
	public void setGmobileno(long gmobileno) {
		this.gmobileno = gmobileno;
	}
	public String getGaddress() {
		return gaddress;
	}
	public void setGaddress(String gaddress) {
		this.gaddress = gaddress;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public double getDetailsofincome() {
		return detailsofincome;
	}
	public void setDetailsofincome(double detailsofincome) {
		this.detailsofincome = detailsofincome;
	}
	public String getPandetails() {
		return pandetails;
	}
	public void setPandetails(String pandetails) {
		this.pandetails = pandetails;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStreetname() {
		return streetname;
	}
	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	

}
