package com.app.main.serviceI;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.app.main.model.Customer;
import com.app.main.model.Enquiry;
import com.app.main.model.Mail;

public interface HomeserviceI {

	Customer saveCustomerdata(Customer e);

	List<Customer> saveCustomermdata(List<Customer> e);

	Iterable<Customer> getallcustdata();

	void updateCustomerdata(Customer ee);

	Iterable<Customer> deletecustdata(int cid);

	List<Customer> savecustmdata(List<Customer> s);

	boolean changeStatus(Integer cid);

	List<Customer> getByStatus(String status);

	Customer getSingleDatacust(int cid);
	
	void emailWithAttachment(Mail email,MultipartFile file1);

}
