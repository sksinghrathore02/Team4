package com.app.main.serviceI;

import com.app.main.model.Ledger;


public interface Ledgerservice {
	Ledger saveLedger(Ledger led);

	Iterable<Ledger> getallLedgerdata();
}
