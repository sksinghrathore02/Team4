package com.app.main.controller;

import java.util.List;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.app.main.model.Customer;
import com.app.main.model.Enquiry;
import com.app.main.repository.Homerepository;
import com.app.main.serviceI.HomeserviceI;
import com.app.main.serviceI.enqserviceI;

import net.bytebuddy.utility.RandomString;
@CrossOrigin("*")
@RestController
public class Enquirycontroller {
	@Autowired
	enqserviceI hr;
	@Autowired
	HomeserviceI hrr;

	@PostMapping(value = "/saveEnquiry")
	public Enquiry savestudent(@RequestBody Enquiry e) {

		Enquiry e1 = hr.saveenquirydata(e);
		return e1;
	}
	@GetMapping(value="/getSingleDataEnquiry/{cid}")
public Enquiry getSingledata1(@PathVariable int cid) {
	Enquiry e=hr.getSingleData1(cid);
		return e;
	}

	@PostMapping(value = "/savemultipleenquiry")
	public List<Enquiry> saveEnquirymultiple(@RequestBody List<Enquiry> e) {

		return hr.saveEnquirymdata(e);
	}

	@GetMapping(value = "/getallenqdata")
	public Iterable<Enquiry> getallstuddata() {

		Iterable<Enquiry> list = hr.getallenqdata();
		return list;
	}

	@PutMapping(value = "/updatedataenq")
	public void updateStudent(@RequestBody Enquiry ee) {

		hr.updateenquirydata(ee);

	}

	@RequestMapping(value = "/deleteenqdata/{cid}", method = RequestMethod.DELETE)
	public Iterable<Enquiry> deletebyidstuddata(@PathVariable("cid") int cid) {
		Iterable<Enquiry> st = hr.deleteenqdata(cid);
		return st;
	}

	@Autowired
	private JavaMailSender javamailsender;

	@GetMapping("/send")
	public String send() {
		SimpleMailMessage m = new SimpleMailMessage();
		m.setTo("priyankakanhekar19@gmail.com");
		m.setSubject("Evcarloan successfully");
		m.setText("Approved");

		javamailsender.send(m);
		return "send";

	}
//	@GetMapping("/getdata/{cid}")
//    public String cibilcheck(@PathVariable int cid)
//    {
//    	//EnquiryDetails ed= serviceenq.enquiry(eId);
//    	//EnquiryDetails edetail=new EnquiryDetails();
//    	int cibilscore=edd.getCibilscore();
//    	edd.setCibilscore(cibilscore);
//    	if(cibilscore>700)
//    	{
//    		//Enquiry ee=hr.saveenquirydata(edd);
//    		Enquiry ee=hr.getSingleData1(cid);
//    		
//    		SimpleMailMessage m=new SimpleMailMessage();
//    		//m.setTo("priyankakanhekar19@gmail.com");
//    		m.setTo(edd.getEmail());
//    		m.setSubject("CIBIL check");
//    		m.setText("Your Application form has been approved for loan");
//
//    		System.out.println("if block");
//    		javamailsender.send(m);
//    	}
//    	else 
//    		{
//    		//Enquiry ee=hr.saveenquirydata(edd);
//    		Enquiry ee=hr.getSingleData1(cid);
//
//    		SimpleMailMessage m=new SimpleMailMessage();
//    		//m.setTo("priyankakanhekar19@gmail.com");
//    		m.setTo(ee.getEmail());
//    		m.setSubject("CIBIL check");
//    		m.setText("Your Application form has NOT been approved for loan");
//
//    		System.out.println("else block");
//    		javamailsender.send(m);
//    		}
//		
//    	
//    	return "cibil score checked";
//    }
	@PostMapping(value="/mailrejectsendEnquiry/{cid}")
public Enquiry sendRejectedMail(@PathVariable int cid) {
		Enquiry e=hr.getSingleData1(cid);
		System.out.println(e.getStatus());
		String status=e.getStatus();
		System.out.println(status);		
			SimpleMailMessage m=new SimpleMailMessage();
			m.setTo(e.getEmail());
			m.setSubject("Loan Rejection Mail");
			m.setText("We are sorry to inform that due to low cibil your enquiry is rejected");			
			javamailsender.send(m);		
		return e;
}



	@RequestMapping(value = "/saveCustentm", method = RequestMethod.POST)
	public List<Customer> savestudentm(@RequestBody List<Customer> s) {
		List<Customer> s1 = hrr.savecustmdata(s);
		for (Customer ss : s1) {

			System.out.println(ss.getEmailid());
			SimpleMailMessage m = new SimpleMailMessage();
			m.setTo(ss.getEmailid());
			m.setSubject("HELlo");
			m.setText("data send");
			javamailsender.send(m);

		}
		return s1;

	}

	/*@GetMapping(value = "/getcibil/{cid}")
	public Integer getCreditscore(@PathVariable int cid) {

		Enquiry e = hr.enquiry(cid);
		int t = e.getCibilscore();
		if (t >= 700) {
			System.out.println("eligible");
			 e.setStatus("eligible");
			//return "eligible";
		} else {

			e.setStatus("lowcibil");
			System.out.println("low cibil");
			//return "lowcibil";
		}
return 11;
	}
	@GetMapping(value = "/getcibill/{cid}")
	public ResponseEntity<Integer> getCreditscore(@PathVariable int cid){
		
		
		int min=600;
		int max=900;
		Random r=new Random();
		int showme=r.nextInt(max);
		Enquiry e = hr.enquiry(cid);
		Integer ik=e.getCibilscore();
		if(ik>700) {
			e.setStatus("eligible");
			
		}
		else {
			e.setStatus("lowcibil");
		}
		
		return new ResponseEntity<Integer>(showme,HttpStatus.OK);
		
		
	}*/
	@GetMapping("/getCibilEnquiry/{cid}")
	 public Integer getcibilScore(@PathVariable int cid) {
	  Enquiry e=hr.enquiry(cid);
	  String endpointUrl="http://localhost:9092/creditscore";
	  
	  RestTemplate rt=new RestTemplate();
	  ResponseEntity<Integer> cib=rt.getForEntity(endpointUrl, Integer.class);
	  Integer cibil=cib.getBody();
	  //Cibil c=new Cibil();
	  
	 e.setCibilscore(cibil);
	  if(cibil>700) {
	   e.setStatus("eligible");   
	  }
	  else {
	   e.setStatus("lowcibil");
	  }
	  hr.saveenquirydata(e);
	  return cibil;
	 }
	@GetMapping("/creditscore")
	 public ResponseEntity<Integer> getCreditScore(){
	  int min=600;
	  int max=900;
	  Random r=new Random();
	  int showMe=r.nextInt(min);
	  return new ResponseEntity<>(showMe,HttpStatus.OK);  
	 }


}


