package com.app.main.serviceImpl;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.app.main.model.Customer;
import com.app.main.model.Enquiry;
import com.app.main.repository.Homerepository;
import com.app.main.serviceI.HomeserviceI;
import com.app.main.repository.EmailJPARepository;
import com.app.main.model.Mail;

@Service
public class HomeserviceImpl implements HomeserviceI {
@Autowired
Homerepository hr;
@Autowired
 JavaMailSender javaMailSender;

@Autowired
EmailJPARepository er;
@Override
public Customer saveCustomerdata(Customer e) {
	// TODO Auto-generated method stub
	return hr.save(e);
}

@Override
public List<Customer> saveCustomermdata(List<Customer> e) {
	// TODO Auto-generated method stub
	return (List<Customer>) hr.saveAll(e);
}

@Override
public Iterable<Customer> getallcustdata() {
	// TODO Auto-generated method stub
	return hr.findAll();
}

@Override
public void updateCustomerdata(Customer ee) {
	// TODO Auto-generated method stub
	hr.save(ee);
}

@Override
public Iterable<Customer> deletecustdata(int cid) {
	// TODO Auto-generated method stub
	hr.deleteById(cid);
	return getallcustdata();
}

@Override
public List<Customer> savecustmdata(List<Customer> s) {
	// TODO Auto-generated method stub
	return (List<Customer>) hr.saveAll(s);
}

@Override
public boolean changeStatus(Integer cid) {
	// TODO Auto-generated method stub
	return  hr.findById(cid) != null;
	
}

@Override
public List<Customer> getByStatus(String status) {
	// TODO Auto-generated method stub
	return hr.findByStatus(status);
}

@Override
public Customer getSingleDatacust(int cid) {
	// TODO Auto-generated method stub
	return hr.findByCid(cid);
}

@Override
public void emailWithAttachment(Mail email,MultipartFile file1) 
{
	SimpleMailMessage mail=new SimpleMailMessage();
	mail.setFrom(email.getFromMail());
	mail.setTo(email.getToMail());
	mail.setSubject(email.getSubject());
	mail.setText(email.getBody());
	System.out.println("In email with attachment");

	try {
		MimeMessage msg=javaMailSender.createMimeMessage();
		
		MimeMessageHelper mime=new MimeMessageHelper(msg,true);
		mime.setFrom(email.getFromMail());
		mime.setTo(email.getToMail());
		mime.setSubject(email.getSubject());
		mime.setText(email.getBody());
		mime.setText("hii <br> your password is"+7876477+" <br> Admin", true);
	
			mime.addAttachment("attachment",file1);
			System.out.println("In try block");
			javaMailSender.send(msg);
			System.out.println("mail sent");
			er.save(email);
			
		} catch (MessagingException e) {
			
			e.printStackTrace();
		}
		


}}
