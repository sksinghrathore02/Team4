package com.app.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.main.model.Ledger;
import com.app.main.repository.LedgerRepository;
import com.app.main.serviceI.Ledgerservice;

@Service
public class LedgerserviceImpl implements Ledgerservice{
@Autowired
LedgerRepository ld;
	@Override
	public Ledger saveLedger(Ledger led) {
		// TODO Auto-generated method stub
		return ld.save(led);
	}

	@Override
	public Iterable<Ledger> getallLedgerdata() {
		// TODO Auto-generated method stub
		return ld.findAll();
	}

}