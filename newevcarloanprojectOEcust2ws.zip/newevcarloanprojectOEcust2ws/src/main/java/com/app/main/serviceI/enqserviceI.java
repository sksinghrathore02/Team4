package com.app.main.serviceI;

import java.util.List;

import com.app.main.model.Enquiry;

public interface enqserviceI {

	Iterable<Enquiry> getallenqdata();

	Enquiry saveenquirydata(Enquiry e);

	List<Enquiry> saveEnquirymdata(List<Enquiry> e);

	void updateenquirydata(Enquiry ee);

	Iterable<Enquiry> deleteenqdata(int cid);

	Enquiry enquiry(int cid);

	Enquiry getSingleData1(int cid);

	

}
