package com.app.main.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.main.model.Sanction;


@Repository
public interface SanctionRepository extends CrudRepository<Sanction, Integer>
{

	Sanction findBySanctionId(int sanctionId);

}
