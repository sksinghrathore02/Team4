package com.app.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EvcarloanprojectOEcustApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvcarloanprojectOEcustApplication.class, args);
	}

}
