package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Profession {
	@Id
	@GeneratedValue
private int professionid;
private String professiontype;
private double professionsalary;
private String profsalarytype;
private String professionworkingperiod;
private String professiondesignation;
public int getProfessionid() {
	return professionid;
}
public void setProfessionid(int professionid) {
	this.professionid = professionid;
}
public String getProfessiontype() {
	return professiontype;
}
public void setProfessiontype(String professiontype) {
	this.professiontype = professiontype;
}
public double getProfessionsalary() {
	return professionsalary;
}
public void setProfessionsalary(double professionsalary) {
	this.professionsalary = professionsalary;
}
public String getProfsalarytype() {
	return profsalarytype;
}
public void setProfsalarytype(String profsalarytype) {
	this.profsalarytype = profsalarytype;
}
public String getProfessionworkingperiod() {
	return professionworkingperiod;
}
public void setProfessionworkingperiod(String professionworkingperiod) {
	this.professionworkingperiod = professionworkingperiod;
}
public String getProfessiondesignation() {
	return professiondesignation;
}
public void setProfessiondesignation(String professiondesignation) {
	this.professiondesignation = professiondesignation;
}

}
