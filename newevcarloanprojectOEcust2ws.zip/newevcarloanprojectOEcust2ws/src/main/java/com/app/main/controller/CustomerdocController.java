package com.app.main.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.MultipartConfigElement;
import javax.servlet.MultipartConfigElement;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.app.main.model.CustomerDocument;
import com.app.main.model.Enquiry;
import com.app.main.serviceI.custdocServicei;
import com.fasterxml.jackson.databind.ObjectMapper;

@CrossOrigin("*")
@RestController
@RequestMapping("/api")
public class CustomerdocController {
	@Autowired
	custdocServicei psi;

	// post api
	

	@PostMapping(value = "/document")
	public void saveDoc(@RequestParam(required=true,value = "profilePhoto") MultipartFile file1,
			@RequestParam(required=true,value = "signature") MultipartFile file2,
			@RequestParam(required=true,value = "adharcardaddressproof") MultipartFile file3,
			@RequestParam(required=true,value = "incomeproof") MultipartFile file4,
			@RequestParam(required=true,value = "pancard") MultipartFile file5 ,

			@RequestPart("cid") String cid) throws IOException
{
		try {
			ObjectMapper om = new ObjectMapper();
			CustomerDocument d = new CustomerDocument();
			CustomerDocument document = om.readValue(cid, CustomerDocument.class);

			d.setCid(document.getCid());
			d.setProfilePhoto(file1.getBytes());
			d.setAdharcardaddressproof(file3.getBytes());
			d.setIncomeproof(file4.getBytes());
			d.setSignature(file2.getBytes());
			d.setPancard(file5.getBytes());
             
			psi.saveDoc(d);
		} catch (Exception e) {
            
			e.printStackTrace();
			// TODO: handle exception
		}
           
	}

	@GetMapping(value = "/getDocs")
	public ResponseEntity<List<CustomerDocument>> getDoc() {
		List<CustomerDocument> docs = psi.getAllDocs();

		return new ResponseEntity<List<CustomerDocument>>(docs, HttpStatus.OK);
	}
	@GetMapping(value="/getSingleData/{cid}")
	public Enquiry getSingledata1(@PathVariable int cid) {
		Enquiry e=psi.getSingleData1(cid);
			return e;
		}
//	@Bean
//
//	  public MultipartResolver multipartResolver() {
//	
//	    CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver();
//	    commonsMultipartResolver.setMaxUploadSize(100000);
//	    commonsMultipartResolver.setDefaultEncoding("UTF-8");
//	    return commonsMultipartResolver;
//	  }


}
