package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;



@Entity
public class CustomerDocument {
	@Id
	@GeneratedValue
	private Integer docId;
	private Integer cid;
	@Lob
	private byte[] profilePhoto;
	@Lob
	private byte[] signature;
	@Lob
	private byte[] pancard;
	@Lob
	private byte[] adharcardaddressproof;
	@Lob
	private byte[] incomeproof;

	public byte[] getAdharcardaddressproof() {
		return adharcardaddressproof;
	}

	public void setAdharcardaddressproof(byte[] adharcardaddressproof) {
		this.adharcardaddressproof = adharcardaddressproof;
	}

	public byte[] getIncomeproof() {
		return incomeproof;
	}

	public void setIncomeproof(byte[] incomeproof) {
		this.incomeproof = incomeproof;
	}

	public Integer getDocId() {
		return docId;
	}

	public void setDocId(Integer docId) {
		this.docId = docId;
	}

	

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public byte[] getProfilePhoto() {
		return profilePhoto;
	}

	public void setProfilePhoto(byte[] profilePhoto) {
		this.profilePhoto = profilePhoto;
	}

	public byte[] getSignature() {
		return signature;
	}

	public void setSignature(byte[] signature) {
		this.signature = signature;
	}

	public byte[] getPancard() {
		return pancard;
	}

	public void setPancard(byte[] pancard) {
		this.pancard = pancard;
	}

//	public CustomerDocument(Integer docId, Integer cid, byte[] profilePhoto, byte[] signature, byte[] pancard,
//			byte[] adharcardaddressproof, byte[] incomeproof) {
//		super();
//		this.docId = docId;
//		this.cid = cid;
//		this.profilePhoto = profilePhoto;
//		this.signature = signature;
//		this.pancard = pancard;
//		this.adharcardaddressproof = adharcardaddressproof;
//		this.incomeproof = incomeproof;
//	}


	public CustomerDocument() {
		super();
		// TODO Auto-generated constructor stub
	}

}
