package com.app.main.serviceI;

import com.app.main.model.Cibil;

public interface Cibilservice {

	Cibil savecibildata(Cibil cb);

	Iterable<Cibil> getallCibildata();
}
