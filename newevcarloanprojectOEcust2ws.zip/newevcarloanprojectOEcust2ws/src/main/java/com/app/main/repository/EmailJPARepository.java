package com.app.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.repository.CrudRepository;

import com.app.main.model.Mail;

public interface EmailJPARepository extends JpaRepository<Mail, Integer>{

}
