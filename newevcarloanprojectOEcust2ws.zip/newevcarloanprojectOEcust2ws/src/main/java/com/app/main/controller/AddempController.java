package com.app.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.Addemp;
import com.app.main.serviceI.AddempService;

@CrossOrigin("*")
@RestController
public class AddempController 
{

	@Autowired
	AddempService addempservice;
	
	@RequestMapping(value ="/saveAddemp" ,method=RequestMethod.POST )
	public Addemp saveAddemp(@RequestBody Addemp ED)
	{
		System.out.println(ED.getFirstname());
		System.out.println(ED.getLastname());
		System.out.println(ED.getRole());
		System.out.println(ED.getEmail());
		System.out.println(ED.getAddress());
		System.out.println(ED.getMobno());
		System.out.println(ED.getEducation());
		Addemp st=addempservice.saveAddemp(ED);
		return st;
	}
	@RequestMapping(value = "/getAllAddemp" ,method =RequestMethod.GET)
	public Iterable<Addemp> getAllEnquiryDetails()
	{
		Iterable<Addemp> list=addempservice.getAllAddemp();
		System.out.println(list);
		return list;
	}
	
	@RequestMapping(value = "/updateAddemp" ,method =RequestMethod.PUT)
	public void updateEnquiryDetails(@RequestBody Addemp ED)
	{
		addempservice.updateAddemp(ED);
		
	}
	
	
}
