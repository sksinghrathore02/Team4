package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Carinfo {
	@Id
	@GeneratedValue
	private int carmodelno;
	private String carname;
	private String brandname;
	private double carprice;
	public int getCarmodelno() {
		return carmodelno;
	}
	public void setCarmodelno(int carmodelno) {
		this.carmodelno = carmodelno;
	}
	public String getCarname() {
		return carname;
	}
	public void setCarname(String carname) {
		this.carname = carname;
	}
	public String getBrandname() {
		return brandname;
	}
	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}
	public double getCarprice() {
		return carprice;
	}
	public void setCarprice(double carprice) {
		this.carprice = carprice;
	}

}
