package com.app.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Currentloandetails {
	@Id
	@GeneratedValue
private int currentloanid;
private int currentloanno;
//@OneToOne(cascade=CascadeType.ALL)
//private Emidetails emidetails;
private int emiamount;
private double loanamount;
private int rateofinterest;
private int tenure;
private double totalamtpaid;
private int processingfees;
private double totalinterest;
private String sanctiondate;

public int getEmiamount() {
	return emiamount;
}
public void setEmiamount(int emiamount) {
	this.emiamount = emiamount;
}
public int getCurrentloanid() {
	return currentloanid;
}
public void setCurrentloanid(int currentloanid) {
	this.currentloanid = currentloanid;
}
public int getCurrentloanno() {
	return currentloanno;
}
public void setCurrentloanno(int currentloanno) {
	this.currentloanno = currentloanno;
}
//public Emidetails getEmidetails() {
//	return emidetails;
//}
//public void setEmidetails(Emidetails emidetails) {
//	this.emidetails = emidetails;
//}
public double getLoanamount() {
	return loanamount;
}
public void setLoanamount(double loanamount) {
	this.loanamount = loanamount;
}
public int getRateofinterest() {
	return rateofinterest;
}
public void setRateofinterest(int rateofinterest) {
	this.rateofinterest = rateofinterest;
}
public int getTenure() {
	return tenure;
}
public void setTenure(int tenure) {
	this.tenure = tenure;
}
public double getTotalamtpaid() {
	return totalamtpaid;
}
public void setTotalamtpaid(double totalamtpaid) {
	this.totalamtpaid = totalamtpaid;
}
public int getProcessingfees() {
	return processingfees;
}
public void setProcessingfees(int processingfees) {
	this.processingfees = processingfees;
}
public double getTotalinterest() {
	return totalinterest;
}
public void setTotalinterest(double totalinterest) {
	this.totalinterest = totalinterest;
}
public String getSanctiondate() {
	return sanctiondate;
}
public void setSanctiondate(String sanctiondate) {
	this.sanctiondate = sanctiondate;
}

}
