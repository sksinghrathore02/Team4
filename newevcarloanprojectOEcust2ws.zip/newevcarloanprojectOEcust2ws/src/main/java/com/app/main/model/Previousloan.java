package com.app.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Previousloan {
	@Id
	@GeneratedValue
private int previousloanid;
private double previousloanamount;
private int previousloantenure;
private double previousloanpaidamount;
private double previousloanremainingAmount;
private int previousloandefaulterCount;
private String previousloanstatus;
private String previousloanremark;
//@OneToOne(cascade=CascadeType.ALL)
//private previousLoanbankDetails previousLoanbankDetails;

public int getPreviousloanid() {
	return previousloanid;
}
public void setPreviousloanid(int previousloanid) {
	this.previousloanid = previousloanid;
}
public double getPreviousloanamount() {
	return previousloanamount;
}
public void setPreviousloanamount(double previousloanamount) {
	this.previousloanamount = previousloanamount;
}
public int getPreviousloantenure() {
	return previousloantenure;
}
public void setPreviousloantenure(int previousloantenure) {
	this.previousloantenure = previousloantenure;
}
public double getPreviousloanpaidamount() {
	return previousloanpaidamount;
}
public void setPreviousloanpaidamount(double previousloanpaidamount) {
	this.previousloanpaidamount = previousloanpaidamount;
}
public double getPreviousloanremainingAmount() {
	return previousloanremainingAmount;
}
public void setPreviousloanremainingAmount(double previousloanremainingAmount) {
	this.previousloanremainingAmount = previousloanremainingAmount;
}
public int getPreviousloandefaulterCount() {
	return previousloandefaulterCount;
}
public void setPreviousloandefaulterCount(int previousloandefaulterCount) {
	this.previousloandefaulterCount = previousloandefaulterCount;
}
public String getPreviousloanstatus() {
	return previousloanstatus;
}
public void setPreviousloanstatus(String previousloanstatus) {
	this.previousloanstatus = previousloanstatus;
}
public String getPreviousloanremark() {
	return previousloanremark;
}
public void setPreviousloanremark(String previousloanremark) {
	this.previousloanremark = previousloanremark;
}


}
