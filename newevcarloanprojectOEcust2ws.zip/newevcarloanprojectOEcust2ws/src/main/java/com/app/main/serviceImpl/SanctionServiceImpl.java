package com.app.main.serviceImpl;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.app.main.*;
import com.app.main.model.ApplicantList;
import com.app.main.model.Customer;
import com.app.main.model.Email;
import com.app.main.model.Sanction;
import com.app.main.repository.ApplicantRepository;
import com.app.main.repository.SanctionRepository;
import com.app.main.serviceI.SanctionServiceI;
import com.app.main.model.Mail;


@Service
public class SanctionServiceImpl implements SanctionServiceI 
{
     @Autowired
        SanctionRepository hr;
     @Autowired
     ApplicantRepository ar;
     @Autowired
 	 JavaMailSender javaMailSender;

      @Override
      		public Sanction saveSanctionLetter(Sanction en) 
      			{
    	  			hr.save(en);
    	  			return en;
	
      			}

      @Override
      		public Iterable<Sanction> getAllSanctionLetter() 
      			{
    	  			return hr.findAll();
      			}

	@Override
	public ApplicantList saveApplicantList(ApplicantList en) 
	{
		ar.save(en);
			return en;	
			}

	@Override
	public Iterable<ApplicantList> getAllApplicantList()
	{
		return ar.findAll();

	}

	
	@Override
	public void updateApplicantListdata(ApplicantList ee) {
		// TODO Auto-generated method stub
		ar.save(ee);
	}

	@Override
	public Iterable<ApplicantList> deleteApplicantListdata(int cid) {
		// TODO Auto-generated method stub
		ar.deleteById(cid);
		return getAllApplicantList();
	}

	@Override
	public void updateSanctiondata(Sanction ee) {
		// TODO Auto-generated method stub
		hr.save(ee);
	}

	@Override
	public Sanction getgetSinglesanction(int sanctionId) {
		// TODO Auto-generated method stub
		return hr.findBySanctionId(sanctionId);
	}

	
//	@Override
//	public void emailWithAttachment(Mail email) 
//	{
//		SimpleMailMessage mail=new SimpleMailMessage();
//		mail.setFrom(email.getFromMail());
//		mail.setTo(email.getToMail());
//		mail.setSubject(email.getSubject());
//		mail.setText(email.getBody());
//
//		try {
//			MimeMessage msg=javaMailSender.createMimeMessage();
//			
//			MimeMessageHelper mime=new MimeMessageHelper(msg,true);
//			mime.setFrom(email.getFromMail());
//			mime.setTo(email.getToMail());
//			mime.setSubject(email.getSubject());
//			mime.setText(email.getBody());
//			mime.setText("hii <br> your password is"+7876477+" <br> Admin", true);
//		
//				//mime.addAttachment("attachment",email.getAttchment());
//				
//				javaMailSender.send(msg);
//				System.out.println("mail sent");
//				
//				
//			} catch (MessagingException e) {
//				
//				e.printStackTrace();
//			}
//			
//				}
//
//	

	

}
