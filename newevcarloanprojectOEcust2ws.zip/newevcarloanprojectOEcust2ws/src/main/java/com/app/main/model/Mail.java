package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.springframework.web.multipart.MultipartFile;
@Entity
public class Mail {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int eid;
	
	private String toMail;
	private String fromMail;
	private String subject;
	private String body;
	@Lob
	private byte[] attchment;
	public String getToMail() {
		return toMail;
	}
	
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public void setToMail(String toMail) {
		this.toMail = toMail;
	}
	public String getFromMail() {
		return fromMail;
	}
	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}

	public byte[] getAttchment() {
		return attchment;
	}

	public void setAttchment(byte[] attchment) {
		this.attchment = attchment;
	}


	
	
	
}
