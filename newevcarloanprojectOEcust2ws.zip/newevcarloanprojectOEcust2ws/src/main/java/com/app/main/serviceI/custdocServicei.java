package com.app.main.serviceI;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.HttpRequestHandler;

import com.app.main.model.CustomerDocument;
import com.app.main.model.Enquiry;


public interface custdocServicei {
	
	
	public void saveDoc(CustomerDocument d);
	public List<CustomerDocument> getAllDocs();
	public Enquiry getSingleData1(int cid);
	
	
}
