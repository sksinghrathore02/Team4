package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Educationdetails {
	@Id
	@GeneratedValue
private int eduid;
private String educationtype;
public int getEduid() {
	return eduid;
}
public void setEduid(int eduid) {
	this.eduid = eduid;
}
public String getEducationtype() {
	return educationtype;
}
public void setEducationtype(String educationtype) {
	this.educationtype = educationtype;
}

}
