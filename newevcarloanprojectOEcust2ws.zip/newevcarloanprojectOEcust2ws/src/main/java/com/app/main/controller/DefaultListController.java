package com.app.main.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.Defaultlist;
import com.app.main.serviceI.DefaultlistService;



@CrossOrigin("*")
@RestController
public class DefaultListController 
{
	@Autowired
	DefaultlistService ds;
	
	
	@RequestMapping(value="/savedefaultdata",method = RequestMethod.POST)
	public Defaultlist savedata(@RequestBody Defaultlist d)
	{
		return ds.savedata(d);
	}
	@RequestMapping(value="/getdefaultdata",method = RequestMethod.GET)
	public Iterable<Defaultlist> getdata()
	{
		return ds.getdata();
	}
}
