package com.app.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.main.model.Sanction;
import com.app.main.serviceI.SanctionServiceI;
import com.app.main.model.ApplicantList;
import com.app.main.model.Enquiry;
import com.app.main.model.Mail;
import com.fasterxml.jackson.databind.ObjectMapper;


@CrossOrigin("*")
@RestController
public class SanctionController 
{
	@Autowired
	SanctionServiceI sanctionService;
	
	
	@RequestMapping(value = "/saveSanctionLetter" ,method=RequestMethod.POST)
	public Sanction saveSanctionLetter(@RequestBody Sanction  en)
	{
	
		System.out.println(en.getSanctionId());
		Sanction  st=sanctionService.saveSanctionLetter(en);
		return st;
	}
	@RequestMapping(value = "/getAllSanction" ,method = RequestMethod.GET)
	public Iterable<Sanction > getAllSanctionLetter()
	{
		Iterable<Sanction > list=sanctionService.getAllSanctionLetter();
		System.out.println(list);
		return list;
	}
	@PutMapping(value="/updateSanctiondata")
	public void updateSanction(@RequestBody Sanction ee) {
		
		sanctionService.updateSanctiondata(ee);
		
	}
	@GetMapping(value="/getSingleDatasanction/{sanctionId}")
	public Sanction getSinglesnction(@PathVariable int  sanctionId) 
	{
		return sanctionService.getgetSinglesanction(sanctionId);
		
	}

	
	
//	@Value("${spring.mail.username}")
//	//String fromMailId;
//	@PostMapping("/email-attach")
//	public String emailWithAttachmentt(@RequestPart("toMail") String toMail,@RequestPart("fromMail") String fromMail,
//			@RequestPart("subject") String subject,@RequestPart("body") String body,
//			@RequestParam(value="attachment") MultipartFile file1) {
//		try {
//			
//			System.out.println("1");
//			ObjectMapper om=new ObjectMapper();			
//			Mail email = new Mail();
//			//Mail email = om.readValue(mail, Mail.class);
//			email.setFromMail(email.getFromMail());
//			email.setAttchment(file1.getBytes());
//			System.out.println(email.getBody());
//			//System.out.println(email.getAttchment());			
//			sanctionService.emailWithAttachment(email);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return "email not sent";
//		}
//
//		return "email sent";
//	}
}
