package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Sanction
{
	@Id
	@GeneratedValue
private int sanctionId;
private String sanctionDate;
private String applicantName;
private double contactDetails;
private String productHomeEnquiry;
private double loanAmountSanctioned;
private String interestType;
private int rateOfInterest;
private int loanTenure;
private double monthlyEmiAmount;
private String modeOfPayment;
private String remarks;
private String termsCondition;
private String status;
public int getSanctionId() {
	return sanctionId;
}
public void setSanctionId(int sanctionId) {
	this.sanctionId = sanctionId;
}
public String getSanctionDate() {
	return sanctionDate;
}
public void setSanctionDate(String sanctionDate) {
	this.sanctionDate = sanctionDate;
}
public String getApplicantName() {
	return applicantName;
}
public void setApplicantName(String applicantName) {
	this.applicantName = applicantName;
}
public double getContactDetails() {
	return contactDetails;
}
public void setContactDetails(double contactDetails) {
	this.contactDetails = contactDetails;
}
public String getProductHomeEnquiry() {
	return productHomeEnquiry;
}
public void setProductHomeEnquiry(String productHomeEnquiry) {
	this.productHomeEnquiry = productHomeEnquiry;
}
public double getLoanAmountSanctioned() {
	return loanAmountSanctioned;
}
public void setLoanAmountSanctioned(double loanAmountSanctioned) {
	this.loanAmountSanctioned = loanAmountSanctioned;
}
public String getInterestType() {
	return interestType;
}
public void setInterestType(String interestType) {
	this.interestType = interestType;
}
public int getRateOfInterest() {
	return rateOfInterest;
}
public void setRateOfInterest(int rateOfInterest) {
	this.rateOfInterest = rateOfInterest;
}
public int getLoanTenure() {
	return loanTenure;
}
public void setLoanTenure(int loanTenure) {
	this.loanTenure = loanTenure;
}
public double getMonthlyEmiAmount() {
	return monthlyEmiAmount;
}
public void setMonthlyEmiAmount(double monthlyEmiAmount) {
	this.monthlyEmiAmount = monthlyEmiAmount;
}
public String getModeOfPayment() {
	return modeOfPayment;
}
public void setModeOfPayment(String modeOfPayment) {
	this.modeOfPayment = modeOfPayment;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
public String getTermsCondition() {
	return termsCondition;
}
public void setTermsCondition(String termsCondition) {
	this.termsCondition = termsCondition;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}



}
