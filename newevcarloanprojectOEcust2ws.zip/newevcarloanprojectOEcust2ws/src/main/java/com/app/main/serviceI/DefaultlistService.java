package com.app.main.serviceI;

import com.app.main.model.Defaultlist;


public interface DefaultlistService
{
public Defaultlist savedata(Defaultlist d);
	
	public Iterable<Defaultlist> getdata();
}
