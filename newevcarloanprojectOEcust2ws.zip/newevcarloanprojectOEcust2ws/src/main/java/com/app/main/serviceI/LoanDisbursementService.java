package com.app.main.serviceI;

import com.app.main.model.LoanDisbursement;

public interface LoanDisbursementService {
	public LoanDisbursement savedata(LoanDisbursement l);
	
	public Iterable<LoanDisbursement> getdata();
}
