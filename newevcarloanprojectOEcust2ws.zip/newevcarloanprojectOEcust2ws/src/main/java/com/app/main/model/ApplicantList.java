package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ApplicantList 
{@Id
	@GeneratedValue
private int id;
private String name;
private int age;
private String emailid;
private double sanctionamount;
private String status;
private String action;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public double getSanctionamount() {
	return sanctionamount;
}
public void setSanctionamount(double sanctionamount) {
	this.sanctionamount = sanctionamount;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getAction() {
	return action;
}
public void setAction(String action) {
	this.action = action;
}

}
