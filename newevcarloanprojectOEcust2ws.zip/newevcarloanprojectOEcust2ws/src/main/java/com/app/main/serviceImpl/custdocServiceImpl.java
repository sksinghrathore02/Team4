package com.app.main.serviceImpl;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.HttpRequestHandler;

import com.app.main.model.CustomerDocument;
import com.app.main.model.Enquiry;
import com.app.main.repository.DocumentRepo;
import com.app.main.serviceI.custdocServicei;
@Service
public class custdocServiceImpl implements custdocServicei {
	
	
	
	@Autowired
	DocumentRepo drepo;
    
	
	@Override
	public void saveDoc(CustomerDocument d) {
		drepo.save(d);
		
	}

	@Override
	public List<CustomerDocument> getAllDocs() {
		
		return drepo.findAll();
	}
    
	@Override
	public Enquiry getSingleData1(int cid) {
		// TODO Auto-generated method stub
		return drepo.findByCid(cid);
	}
	
	
	
    
}
