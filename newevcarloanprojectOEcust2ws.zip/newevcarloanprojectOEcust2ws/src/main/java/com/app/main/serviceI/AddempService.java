package com.app.main.serviceI;

import com.app.main.model.Addemp;

public interface AddempService {

	Addemp saveAddemp(Addemp ED);

	Iterable<Addemp> getAllAddemp();

	void updateAddemp(Addemp eD);

}
