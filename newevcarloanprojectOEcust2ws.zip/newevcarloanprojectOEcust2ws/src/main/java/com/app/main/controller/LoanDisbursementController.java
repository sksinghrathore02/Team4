package com.app.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.LoanDisbursement;
import com.app.main.serviceI.LoanDisbursementService;




@CrossOrigin("*")
@RestController
public class LoanDisbursementController {

	@Autowired
	LoanDisbursementService ls;
	
	
	@RequestMapping(value="/saveloandata",method = RequestMethod.POST)
	public LoanDisbursement savedata(@RequestBody LoanDisbursement l)
	{
		return ls.savedata(l);
	}
	@RequestMapping(value="/getloandata",method = RequestMethod.GET)
	public Iterable<LoanDisbursement> getdata()
	{
		return ls.getdata();
	}
}
