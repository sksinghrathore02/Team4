package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.springframework.web.multipart.MultipartFile;


@Entity
public class Email {
	
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private String sender;
	private String receiver;
	private String status;
//	private String toMail;
//	private String fromMail;
//	private String subject;
//	private String body;
//	@Lob
//	private MultipartFile attchment;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
//	public String getToMail() {
//		return toMail;
//	}
//	public void setToMail(String toMail) {
//		this.toMail = toMail;
//	}
//	public String getFromMail() {
//		return fromMail;
//	}
//	public void setFromMail(String fromMail) {
//		this.fromMail = fromMail;
//	}
//	public String getSubject() {
//		return subject;
//	}
//	public void setSubject(String subject) {
//		this.subject = subject;
//	}
//	public String getBody() {
//		return body;
//	}
//	public void setBody(String body) {
//		this.body = body;
//	}
//	public MultipartFile getAttchment() {
//		return attchment;
//	}
//	public void setAttchment(MultipartFile attchment) {
//		this.attchment = attchment;
//	}
//	
}
