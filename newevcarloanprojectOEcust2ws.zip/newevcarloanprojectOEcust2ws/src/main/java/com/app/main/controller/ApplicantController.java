package com.app.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.ApplicantList;
import com.app.main.model.Customer;
import com.app.main.serviceI.SanctionServiceI;

@CrossOrigin("*")
@RestController
public class ApplicantController {
	@Autowired
	SanctionServiceI sanctionService;
	
	
	@RequestMapping(value = "/saveApplicantList" ,method=RequestMethod.POST)
	public ApplicantList saveSanctionLetter(@RequestBody ApplicantList  en)
	{
	
		System.out.println(en.getId());
		ApplicantList  st=sanctionService.saveApplicantList(en);
		return st;
	}
	@RequestMapping(value = "/getAllApplicantList" ,method = RequestMethod.GET)
	public Iterable<ApplicantList> getAllApplicantList()
	{
		Iterable<ApplicantList> list=sanctionService.getAllApplicantList();
		System.out.println(list);
		return list;
	}
	
	@PutMapping(value="/updateApplicantListdata")
	public void updateApplicantList(@RequestBody ApplicantList ee) {
		
		sanctionService.updateApplicantListdata(ee);
		
	}
	@RequestMapping(value="/deleteApplicantListdata/{id}",method=RequestMethod.DELETE)
	public Iterable<ApplicantList> deletebyidcustdata(@PathVariable("id")int id){
		Iterable<ApplicantList> st=sanctionService.deleteApplicantListdata(id);
		return st;}

}
