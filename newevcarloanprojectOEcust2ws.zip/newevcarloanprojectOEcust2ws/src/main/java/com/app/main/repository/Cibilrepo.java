package com.app.main.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.main.model.Cibil;
import com.app.main.model.Enquiry;
@Repository
public interface Cibilrepo extends CrudRepository<Cibil, Integer>{

	

	Enquiry findByCid(int cid);

}
