package com.app.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class previousLoanbankDetails {
@Id
@GeneratedValue
private int branchid;
private String branchname;
private double branchcode;
private double contactnumber;
private String IFSCcode;
private String Micrcode;
private String branchtype;
private String Email;
private String status;
private String bankaddress;
//@OneToOne(cascade=CascadeType.ALL)
//private  BankAddress bankaddress;
public int getBranchid() {
	return branchid;
}
public String getBankaddress() {
	return bankaddress;
}
public void setBankaddress(String bankaddress) {
	this.bankaddress = bankaddress;
}
public void setBranchid(int branchid) {
	this.branchid = branchid;
}
public String getBranchname() {
	return branchname;
}
public void setBranchname(String branchname) {
	this.branchname = branchname;
}
public double getBranchcode() {
	return branchcode;
}
public void setBranchcode(double branchcode) {
	this.branchcode = branchcode;
}
public double getContactnumber() {
	return contactnumber;
}
public void setContactnumber(double contactnumber) {
	this.contactnumber = contactnumber;
}
public String getIFSCcode() {
	return IFSCcode;
}
public void setIFSCcode(String iFSCcode) {
	IFSCcode = iFSCcode;
}
public String getMicrcode() {
	return Micrcode;
}
public void setMicrcode(String micrcode) {
	Micrcode = micrcode;
}
public String getBranchtype() {
	return branchtype;
}
public void setBranchtype(String branchtype) {
	this.branchtype = branchtype;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
//public BankAddress getBankaddress() {
//	return bankaddress;
//}
//public void setBankaddress(BankAddress bankaddress) {
//	this.bankaddress = bankaddress;
//}

}
