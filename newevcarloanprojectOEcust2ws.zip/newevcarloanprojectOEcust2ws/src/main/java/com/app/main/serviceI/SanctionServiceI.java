package com.app.main.serviceI;

import java.util.List;

import com.app.main.model.ApplicantList;
import com.app.main.model.Mail;
import com.app.main.model.Sanction;





public interface SanctionServiceI 
{

Sanction saveSanctionLetter(Sanction en);

Iterable<Sanction> getAllSanctionLetter();

ApplicantList saveApplicantList(ApplicantList en);

Iterable<ApplicantList> getAllApplicantList();



void updateApplicantListdata(ApplicantList ee);

Iterable<ApplicantList> deleteApplicantListdata(int cid);
//void emailWithAttachment(Mail email);

void updateSanctiondata(Sanction ee);

Sanction getgetSinglesanction(int sanctionId);


}
