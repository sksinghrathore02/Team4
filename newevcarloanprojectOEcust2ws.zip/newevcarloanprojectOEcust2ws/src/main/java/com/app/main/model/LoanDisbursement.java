package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class LoanDisbursement {
	@Id
	@GeneratedValue
private int agreementId;
private int loanNo;
private String agreementDate;
private String amountPayType;
private Double totalAmount;
private String bankName;
private Long accountNumber;
private String IFSCCode;
private String accountType;
private Double transferAmount;
private String paymentStatus;
private String ammountPaidDate;
public int getAgreementId() {
	return agreementId;
}
public void setAgreementId(int agreementId) {
	this.agreementId = agreementId;
}
public int getLoanNo() {
	return loanNo;
}
public void setLoanNo(int loanNo) {
	this.loanNo = loanNo;
}
public String getAgreementDate() {
	return agreementDate;
}
public void setAgreementDate(String agreementDate) {
	this.agreementDate = agreementDate;
}
public String getAmountPayType() {
	return amountPayType;
}
public void setAmountPayType(String amountPayType) {
	this.amountPayType = amountPayType;
}
public Double getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(Double totalAmount) {
	this.totalAmount = totalAmount;
}
public String getBankName() {
	return bankName;
}
public void setBankName(String bankName) {
	this.bankName = bankName;
}
public Long getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(Long accountNumber) {
	this.accountNumber = accountNumber;
}
public String getIFSCCode() {
	return IFSCCode;
}
public void setIFSCCode(String iFSCCode) {
	IFSCCode = iFSCCode;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public Double getTransferAmount() {
	return transferAmount;
}
public void setTransferAmount(Double transferAmount) {
	this.transferAmount = transferAmount;
}
public String getPaymentStatus() {
	return paymentStatus;
}
public void setPaymentStatus(String paymentStatus) {
	this.paymentStatus = paymentStatus;
}
public String getAmmountPaidDate() {
	return ammountPaidDate;
}
public void setAmmountPaidDate(String ammountPaidDate) {
	this.ammountPaidDate = ammountPaidDate;
}
}
