package com.app.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.Ledger;
import com.app.main.serviceI.Ledgerservice;

@CrossOrigin("*")
@RestController
public class LedgerController {
	@Autowired
	Ledgerservice Ledger;
	@RequestMapping(value="/saveLedger", method=RequestMethod.POST )
    public Ledger saveLedger(@RequestBody Ledger led)
    {
		System.out.println("save");
	
		Ledger e=Ledger.saveLedger(led);
		
		return e;
    }
	@RequestMapping(value="/getallLedgerdata", method=RequestMethod.GET)
	public Iterable<Ledger> getallLedgerdata()
	{
		Iterable<Ledger> list=Ledger.getallLedgerdata();
		return list;
		
	}
}
