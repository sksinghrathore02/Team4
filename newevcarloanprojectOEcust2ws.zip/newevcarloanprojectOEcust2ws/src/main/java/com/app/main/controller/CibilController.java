package com.app.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.main.model.Cibil;
import com.app.main.serviceI.Cibilservice;

@CrossOrigin("*")
@RestController
public class CibilController {
	@Autowired
	Cibilservice cibil;
	@RequestMapping(value="/savecibildata", method=RequestMethod.POST )
    public  Cibil savecibildata(@RequestBody Cibil cb)
    {
		System.out.println("save");
	
		 Cibil c= cibil.savecibildata(cb);
		
		return c;
    }
	@RequestMapping(value="/getallCibildata", method=RequestMethod.GET)
	public Iterable<Cibil> getallCibildata()
	{
		Iterable<Cibil> list=cibil.getallCibildata();
		return list;
		
	}

}
