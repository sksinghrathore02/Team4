package com.app.main.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.main.model.Cibil;

public interface Cibilrepository extends CrudRepository<Cibil, Integer>{

}
