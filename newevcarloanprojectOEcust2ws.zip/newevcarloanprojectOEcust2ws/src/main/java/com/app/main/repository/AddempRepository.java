package com.app.main.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.main.model.Addemp;

public interface AddempRepository extends CrudRepository<Addemp, Integer> {

}
