package com.app.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.main.model.LoanDisbursement;
import com.app.main.repository.LoanDisbursementRepositry;
import com.app.main.serviceI.LoanDisbursementService;



@Service
public class LoanDisbursementServiceImpl  implements LoanDisbursementService{
@Autowired
LoanDisbursementRepositry lr;
	
	@Override
	public LoanDisbursement savedata(LoanDisbursement l) {
		// TODO Auto-generated method stub
		return lr.save(l);
	}

	@Override
	public Iterable<LoanDisbursement> getdata() {
		// TODO Auto-generated method stub
		return lr.findAll();
	}

}
