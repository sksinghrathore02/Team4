package com.app.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.main.model.Cibil;
import com.app.main.repository.Cibilrepository;
import com.app.main.serviceI.Cibilservice;

@Service
public class CibilserviceImpl implements Cibilservice  {
@Autowired

Cibilrepository ci;
	@Override
	public Cibil savecibildata(Cibil cb) {
		// TODO Auto-generated method stub
		return ci.save(cb);
	}

	@Override
	public Iterable<Cibil> getallCibildata() {
		// TODO Auto-generated method stub
		return ci.findAll();
	}

}
