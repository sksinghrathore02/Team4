package com.app.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int cid;
	private String cname;
	private int age;
	private String emailid;
	private String status;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Carinfo carinfo;
	@OneToOne(cascade=CascadeType.ALL)
	private Accountdetails accdetails;
@OneToOne(cascade=CascadeType.ALL)
private Educationdetails edudetails;	
@OneToOne(cascade=CascadeType.ALL)
private Profession profession;
@OneToOne(cascade=CascadeType.ALL)
private CustomerAddress customeraddress;
@OneToOne(cascade=CascadeType.ALL)
private Currentloandetails currentloan;
@OneToOne(cascade=CascadeType.ALL)
private Garantordetails garantordetails;
@OneToOne(cascade=CascadeType.ALL)
private Sanction sanction;

public Sanction getSanction() {
	return sanction;
}
public void setSanction(Sanction sanction) {
	this.sanction = sanction;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Carinfo getCarinfo() {
	return carinfo;
}
public void setCarinfo(Carinfo carinfo) {
	this.carinfo = carinfo;
}
public Accountdetails getAccdetails() {
	return accdetails;
}
public void setAccdetails(Accountdetails accdetails) {
	this.accdetails = accdetails;
}
public Educationdetails getEdudetails() {
	return edudetails;
}
public void setEdudetails(Educationdetails edudetails) {
	this.edudetails = edudetails;
}
public Profession getProfession() {
	return profession;
}
public void setProfession(Profession profession) {
	this.profession = profession;
}
public CustomerAddress getCustomeraddress() {
	return customeraddress;
}
public void setCustomeraddress(CustomerAddress customeraddress) {
	this.customeraddress = customeraddress;
}

public Currentloandetails getCurrentloan() {
	return currentloan;
}
public void setCurrentloan(Currentloandetails currentloan) {
	this.currentloan = currentloan;
}
public Garantordetails getGarantordetails() {
	return garantordetails;
}
public void setGarantordetails(Garantordetails garantordetails) {
	this.garantordetails = garantordetails;
}


}
