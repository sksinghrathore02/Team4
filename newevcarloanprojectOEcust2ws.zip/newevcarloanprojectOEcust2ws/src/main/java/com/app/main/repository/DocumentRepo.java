package com.app.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.main.model.CustomerDocument;
import com.app.main.model.Enquiry;
@Repository
public interface DocumentRepo extends JpaRepository<CustomerDocument, Integer> {

	Enquiry findByCid(int cid);

}
