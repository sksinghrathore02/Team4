package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Cibil {
@Id
@GeneratedValue
private int cid;
private int cibilscore;
private int scoreabove;
private int scorebelow;
private int mark;
public int getId() {
	return cid;
}
public void setId(int cid) {
	this.cid =cid;
}
public int getScoreabove() {
	return scoreabove;
}
public void setScoreabove(int scoreabove) {
	this.scoreabove = scoreabove;
}
public int getScorebelow() {
	return scorebelow;
}
public void setScorebelow(int scorebelow) {
	this.scorebelow = scorebelow;
}
public int getMark() {
	return mark;
}
public void setMark(int mark) {
	this.mark = mark;
}

}
