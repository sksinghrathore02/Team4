package com.app.main.controller;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.main.model.Customer;
import com.app.main.model.Enquiry;
import com.app.main.model.Mail;
import com.app.main.serviceI.HomeserviceI;
import com.app.main.model.Email;
import com.app.main.model.Mail;
@CrossOrigin("*")
@RestController
public class Homecontroller {
	@Autowired
	HomeserviceI hr;
	@Autowired
	private JavaMailSender javamailsender;

	@PostMapping(value="/saveCustomer")
	public int saveCustomer(@RequestBody Customer e) {
		
		
		Customer e1=hr.saveCustomerdata(e);
		 
		int cid=e1.getCid();
		return cid;}

	@PostMapping(value="/savemultiplecustmer")
	public List<Customer> saveCustomermultiple(@RequestBody List<Customer> e) {
			
		
			return hr.saveCustomermdata(e);
		}


	@GetMapping(value="/getallcustdata")
	public Iterable<Customer> getallcustdata(){
		
		Iterable<Customer> list=hr.getallcustdata();
		return list;
	}

	@PutMapping(value="/updatedata")
	public void updateCustomer(@RequestBody Customer ee) {
		
		hr.updateCustomerdata(ee);
		
	}
	@RequestMapping(value="/deletecustdata/{cid}",method=RequestMethod.DELETE)
	public Iterable<Customer> deletebyidcustdata(@PathVariable("cid")int cid){
		Iterable<Customer> st=hr.deletecustdata(cid);
		return st;}


	@GetMapping("/changestatus/{cid}")
	public String changestatus (@PathVariable Integer cid) {
	
boolean status=hr.changeStatus(cid);
	
		if(status==true) {
			return "Success";
		}
		
		else {
				return "Operationfail";
		}
		
		}
	@GetMapping(value ="/getbystatus/{status}")
	public List<Customer> getApplicantListByStatus(@PathVariable("status") String status )
	{		
		return hr.getByStatus(status);		
	}
	@PostMapping(value="/mailsendSanction/{cid}")
	public Customer sendRejectedMail(@PathVariable int cid) {
		Customer e=hr.getSingleDatacust(cid);
			System.out.println(e.getStatus());
			String status=e.getStatus();
			System.out.println(status);		
				SimpleMailMessage m=new SimpleMailMessage();
				m.setTo(e.getEmailid());
				m.setSubject("");
				m.setText("We are sorry to inform that due to low cibil your enquiry is rejected");			
				javamailsender.send(m);		
			return e;
	}

	@Value("${spring.mail.username}")
	String fromMailId;

	@RequestMapping(value = "/email-attach",method = RequestMethod.POST)
	public String emailWithAttachment(@RequestPart("toMail") String toMail,@RequestPart("fromMail") String fromMail,
			@RequestPart("subject") String subject,@RequestPart("body") String body,
			@RequestParam(value = "attchment") MultipartFile file1) 

	{
			try {
				//Customer e=hr.getSingleDatacust(cid);
			System.out.println("1");
//			ObjectMapper om = new ObjectMapper();			
			Mail email = new Mail();
			//SimpleMailMessage m=new SimpleMailMessage();
			//m.setTo(e.getEmailid());
//			Email email = om.readValue(mail, Email.class);
			email.setFromMail(fromMail);
			//email.setToMail(e.getEmailid());
			email.setToMail(toMail);
			email.setSubject("hi");
	
			email.setBody("sanction approved");
			byte [] byteArr=file1.getBytes();
			InputStream inputStream = new ByteArrayInputStream(byteArr);
			email.setAttchment(byteArr);
			System.out.println(email.getBody());
			System.out.println(email.getAttchment());			
			hr.emailWithAttachment(email,file1);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			   return "email not sent";
			}
		return "email sent";
	}
	
//	@GetMapping("/mailsendDefaulter/{cid}")
//	public List <Ledger> sendDefaulterMail() {
	
	
//	    List <Ledger> data = usi.getTheListLedger();
//		
//		data.forEach((l)->{
//			if(l.getDefaulterCount()>3) {
//				int l1=l.getLedgerId();
//				Customer u=usi.getcustomerbyledgerId(l);
//				SimpleMailMessage m=new SimpleMailMessage();
//				m.setTo(u.getCustomerEmail());
//				m.setSubject("Loan Defaulter Mail");
//				m.setText(u.getCustomerName()+" Your loan installment is pending kindly pay within 1 month or strict action will be taken");			
//				javamailsender.send(m);	
//			}
//		});
//				
//					
//		return data;
//	}
}




