package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Enquiry {
@Id
@GeneratedValue
private int cid;
private String firstname;
private String lastname;
private int age;
private String email;
private long mobileno;
private String pancardno;
private int cibilscore;
private String status;

public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMobileno() {
	return mobileno;
}
public void setMobileno(long mobileno) {
	this.mobileno = mobileno;
}
public String getPancardno() {
	return pancardno;
}
public void setPancardno(String pancardno) {
	this.pancardno = pancardno;
}
public int getCibilscore() {
	return cibilscore;
}
public void setCibilscore(int cibilscore) {
	this.cibilscore = cibilscore;
}

}
