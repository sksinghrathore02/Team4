package com.app.main.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.app.main.model.Enquiry;
import com.app.main.repository.Cibilrepo;
import com.app.main.repository.enqrepository;
import com.app.main.serviceI.enqserviceI;

@Service
public class enqserviceImpl implements enqserviceI {
@Autowired
enqrepository hr;
@Autowired
Cibilrepo hrr;
@Override
public Iterable<Enquiry> getallenqdata() {
	// TODO Auto-generated method stub
	return hr.findAll();
}

@Override
public Enquiry saveenquirydata(Enquiry e) {
	// TODO Auto-generated method stub
	return hr.save(e);
}

@Override
public List<Enquiry> saveEnquirymdata(List<Enquiry> e) {
	// TODO Auto-generated method stub
	return (List<Enquiry>) hr.saveAll(e);
}

@Override
public void updateenquirydata(Enquiry ee) {
	// TODO Auto-generated method stub
	hr.save(ee);
}

@Override
public Iterable<Enquiry> deleteenqdata(int cid) {
	// TODO Auto-generated method stub
	hr.deleteById(cid);
	return getallenqdata();
}

@Override
public Enquiry enquiry(int cid) {
	// TODO Auto-generated method stub
	
	return  hr.findByCid(cid);
	
}

@Override
public Enquiry getSingleData1(int cid) {
	// TODO Auto-generated method stub
	return hr.findByCid(cid);
}


}
