package com.app.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Emidetails {
	@Id
	@GeneratedValue
private int emailid;
private String emiAmountMonthly;
private String nextemiduedate;
private String previousemistatus;
public int getEmailid() {
	return emailid;
}
public void setEmailid(int emailid) {
	this.emailid = emailid;
}
public String getEmiAmountMonthly() {
	return emiAmountMonthly;
}
public void setEmiAmountMonthly(String emiAmountMonthly) {
	this.emiAmountMonthly = emiAmountMonthly;
}
public String getNextemiduedate() {
	return nextemiduedate;
}
public void setNextemiduedate(String nextemiduedate) {
	this.nextemiduedate = nextemiduedate;
}
public String getPreviousemistatus() {
	return previousemistatus;
}
public void setPreviousemistatus(String previousemistatus) {
	this.previousemistatus = previousemistatus;
}

}
