package com.app.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.main.model.Addemp;
import com.app.main.repository.AddempRepository;
import com.app.main.serviceI.AddempService;


@Service
public class AddempServiceimpl implements AddempService {

	@Autowired
	AddempRepository addemprepo;
	
	@Override
	public Addemp saveAddemp(Addemp ED) {
		// TODO Auto-generated method stub
		addemprepo.save(ED);
		return ED;
	}

	@Override
	public Iterable<Addemp> getAllAddemp() {
		// TODO Auto-generated method stub
		return addemprepo.findAll();
	}

	@Override
	public void updateAddemp(Addemp ED) {
		// TODO Auto-generated method stub
		
		addemprepo.save(ED);
	}

}
