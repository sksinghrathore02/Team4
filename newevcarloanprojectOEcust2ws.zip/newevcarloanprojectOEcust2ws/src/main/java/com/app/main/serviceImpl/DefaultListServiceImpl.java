package com.app.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.main.model.Defaultlist;
import com.app.main.repository.DefaultListRepository;
import com.app.main.serviceI.DefaultlistService;

@Service
public class DefaultListServiceImpl implements DefaultlistService
{
	@Autowired
	DefaultListRepository dr;

	@Override
	public Defaultlist savedata(Defaultlist d) {
		// TODO Auto-generated method stub
		return dr.save(d);
	}

	@Override
	public Iterable<Defaultlist> getdata() {
		// TODO Auto-generated method stub
		return dr.findAll();
	}

}
